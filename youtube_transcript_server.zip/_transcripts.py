# Dummy _transcripts.py for structure
# Replace this with your actual _transcripts.py content if needed
class TranscriptListFetcher:
    def __init__(self, video_id):
        self.video_id = video_id

    def get_transcript(self):
        return [{'text': 'Example transcript line 1'}, {'text': 'Example transcript line 2'}]